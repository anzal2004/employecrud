# app.py

from flask import Flask
from extensions import mysql
from routes.auth_routes import auth_bp
from routes.employee_routes import employee_bp
from routes.attendance_routes import attendance_bp
from routes.report_routes import report_bp

app = Flask(__name__)
app.config.from_pyfile('config.py')

# Initialize MySQL extension
mysql.init_app(app)

# Register Blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(employee_bp, url_prefix='/employee')
app.register_blueprint(attendance_bp, url_prefix='/attendance')
app.register_blueprint(report_bp, url_prefix='/reports')

if __name__ == '__main__':
    app.run(debug=True)
